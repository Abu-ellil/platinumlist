exports.id=8669,exports.ids=[8669],exports.modules={6745:(e,t,s)=>{"use strict";s.d(t,{C:()=>E});var i=s(87550),a=s.n(i),r=s(33873),n=s.n(r),l=s(29021),c=s.n(l);class o{constructor(e={}){this.options={dbPath:e.dbPath||"./data/events.db",tableName:e.tableName||"manual_events",citiesTable:e.citiesTable||"cities",...e},this.db=null,this.isInitialized=!1}async init(){if(!this.isInitialized)try{let e=n().dirname(this.options.dbPath);c().existsSync(e)||c().mkdirSync(e,{recursive:!0}),this.db=new(a())(this.options.dbPath),this.db.pragma("foreign_keys = OFF"),this.db.pragma("journal_mode = WAL"),this.db.exec(`
        CREATE TABLE IF NOT EXISTS ${this.options.citiesTable} (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          slug TEXT UNIQUE NOT NULL,
          name_ar TEXT NOT NULL,
          name_en TEXT NOT NULL,
          country TEXT DEFAULT 'SA',
          is_active INTEGER DEFAULT 1,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `),this.db.exec(`
        CREATE TABLE IF NOT EXISTS ${this.options.tableName} (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          city_slug TEXT NOT NULL,
          slug TEXT UNIQUE,
          title TEXT NOT NULL,
          description TEXT,
          price TEXT,
          crossed_price TEXT,
          global_price TEXT,
          gold_price TEXT,
          platinum_price TEXT,
          vip_price TEXT,
          silver_price TEXT,
          diamond_price TEXT,
          pricing_currency TEXT DEFAULT 'SAR',
          date TEXT,
          start_time TEXT,
          end_time TEXT,
          venue TEXT,
          address TEXT,
          google_maps_link TEXT,
          category TEXT,
          label TEXT,
          rating TEXT,
          accelerator TEXT,
          accelerator_type TEXT,
          discount TEXT,
          href TEXT,
          external_url TEXT,
          image_url TEXT,
          image_full TEXT,
          mobile_thumb TEXT,
          alt TEXT,
          is_featured INTEGER DEFAULT 0,
          is_active INTEGER DEFAULT 1,
          priority INTEGER DEFAULT 0,
          tags TEXT,
          metadata TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `),this.db.exec(`
        CREATE TABLE IF NOT EXISTS settings (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          key TEXT UNIQUE NOT NULL,
          value TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `),this.db.exec(`
        CREATE TABLE IF NOT EXISTS otps (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          email TEXT UNIQUE NOT NULL,
          code TEXT NOT NULL,
          expires_at INTEGER NOT NULL,
          attempts INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);try{this.db.exec(`ALTER TABLE ${this.options.tableName} ADD COLUMN slug TEXT`),console.log("Added slug column to events table")}catch(e){console.log("Slug column already exists or error adding it:",e.message)}for(let e of["global_price","gold_price","platinum_price","vip_price","silver_price","diamond_price","pricing_currency"])try{let t="pricing_currency"===e?'TEXT DEFAULT "SAR"':"TEXT";this.db.exec(`ALTER TABLE ${this.options.tableName} ADD COLUMN ${e} ${t}`),console.log(`Added ${e} column to events table`)}catch(t){console.log(`${e} column already exists or error adding it:`,t.message)}try{this.db.exec(`ALTER TABLE ${this.options.tableName} ADD COLUMN google_maps_link TEXT`),console.log("Added google_maps_link column to events table")}catch(e){console.log("google_maps_link column already exists or error adding it:",e.message)}try{this.db.exec("ALTER TABLE settings ADD COLUMN category TEXT DEFAULT 'general'"),console.log("Added category column to settings table")}catch(e){console.log("Category column already exists or error adding it:",e.message)}try{this.db.exec("ALTER TABLE settings ADD COLUMN description TEXT"),console.log("Added description column to settings table")}catch(e){console.log("Description column already exists or error adding it:",e.message)}try{this.db.exec("ALTER TABLE settings ADD COLUMN is_active INTEGER DEFAULT 1"),console.log("Added is_active column to settings table")}catch(e){console.log("Is_active column already exists or error adding it:",e.message)}this.needsSlugsGeneration=!0,this.db.exec(`
        CREATE INDEX IF NOT EXISTS idx_events_city_slug ON ${this.options.tableName}(city_slug);
        CREATE INDEX IF NOT EXISTS idx_events_slug ON ${this.options.tableName}(slug);
        CREATE INDEX IF NOT EXISTS idx_events_is_active ON ${this.options.tableName}(is_active);
        CREATE INDEX IF NOT EXISTS idx_events_is_featured ON ${this.options.tableName}(is_featured);
        CREATE INDEX IF NOT EXISTS idx_events_priority ON ${this.options.tableName}(priority);
        CREATE INDEX IF NOT EXISTS idx_events_created_at ON ${this.options.tableName}(created_at);
        CREATE INDEX IF NOT EXISTS idx_cities_slug ON ${this.options.citiesTable}(slug);
        CREATE INDEX IF NOT EXISTS idx_cities_is_active ON ${this.options.citiesTable}(is_active);
        CREATE INDEX IF NOT EXISTS idx_settings_key ON settings(key);
        CREATE INDEX IF NOT EXISTS idx_settings_category ON settings(category);
        CREATE INDEX IF NOT EXISTS idx_settings_is_active ON settings(is_active);
        CREATE INDEX IF NOT EXISTS idx_otps_email ON otps(email);
        CREATE INDEX IF NOT EXISTS idx_otps_expires_at ON otps(expires_at);
      `),this.statements={getAllEvents:this.db.prepare(`
          SELECT * FROM ${this.options.tableName} 
          WHERE is_active = 1 
          ORDER BY priority DESC, created_at DESC
        `),getEventsByCity:this.db.prepare(`
          SELECT * FROM ${this.options.tableName} 
          WHERE city_slug = ? AND is_active = 1 
          ORDER BY priority DESC, created_at DESC
        `),getEventById:this.db.prepare(`
          SELECT * FROM ${this.options.tableName} 
          WHERE id = ?
        `),getEventBySlug:this.db.prepare(`
          SELECT * FROM ${this.options.tableName} 
          WHERE slug = ? AND is_active = 1
        `),checkSlugExists:this.db.prepare(`
          SELECT id FROM ${this.options.tableName} 
          WHERE slug = ?
        `),insertEvent:this.db.prepare(`
          INSERT INTO ${this.options.tableName} (
            city_slug, slug, title, description, price, crossed_price, global_price, gold_price, 
            platinum_price, vip_price, silver_price, diamond_price, pricing_currency, date, start_time, end_time,
            venue, address, google_maps_link, category, label, rating, accelerator, accelerator_type, discount,
            href, external_url, image_url, image_full, mobile_thumb, alt, is_featured,
            is_active, priority, tags, metadata
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `),updateEvent:this.db.prepare(`
          UPDATE ${this.options.tableName} SET
            title = ?, description = ?, price = ?, crossed_price = ?, global_price = ?, gold_price = ?,
            platinum_price = ?, vip_price = ?, silver_price = ?, pricing_currency = ?, date = ?, start_time = ?,
            end_time = ?, venue = ?, address = ?, google_maps_link = ?, category = ?, label = ?, rating = ?,
            accelerator = ?, accelerator_type = ?, discount = ?, href = ?, external_url = ?,
            image_url = ?, image_full = ?, mobile_thumb = ?, alt = ?, is_featured = ?,
            is_active = ?, priority = ?, tags = ?, metadata = ?, updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `),deleteEvent:this.db.prepare(`DELETE FROM ${this.options.tableName} WHERE id = ?`),toggleEventStatus:this.db.prepare(`
          UPDATE ${this.options.tableName} SET 
            is_active = ?, updated_at = CURRENT_TIMESTAMP 
          WHERE id = ?
        `),getAllCities:this.db.prepare(`
          SELECT * FROM ${this.options.citiesTable} 
          WHERE is_active = 1 
          ORDER BY name_ar
        `),getCityBySlug:this.db.prepare(`
          SELECT * FROM ${this.options.citiesTable} 
          WHERE slug = ?
        `),insertCity:this.db.prepare(`
          INSERT INTO ${this.options.citiesTable} (slug, name_ar, name_en, country, is_active) 
          VALUES (?, ?, ?, ?, ?)
        `),updateCity:this.db.prepare(`
          UPDATE ${this.options.citiesTable} SET
            name_ar = ?, name_en = ?, country = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
          WHERE slug = ?
        `),getEventStats:this.db.prepare(`
          SELECT 
            COUNT(*) as total_events,
            COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_events,
            COUNT(CASE WHEN is_featured = 1 THEN 1 END) as featured_events,
            COUNT(DISTINCT city_slug) as cities_with_events
          FROM ${this.options.tableName}
        `),getCityEventCounts:this.db.prepare(`
          SELECT 
            city_slug, 
            COUNT(*) as total_events,
            COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_events,
            COUNT(CASE WHEN is_featured = 1 THEN 1 END) as featured_events
          FROM ${this.options.tableName}
          GROUP BY city_slug
        `),getAllSettings:this.db.prepare(`
          SELECT * FROM settings 
          WHERE is_active = 1 
          ORDER BY category, key
        `),getSettingByKey:this.db.prepare(`
          SELECT * FROM settings 
          WHERE key = ? AND is_active = 1
        `),getSettingsByCategory:this.db.prepare(`
          SELECT * FROM settings 
          WHERE category = ? AND is_active = 1 
          ORDER BY key
        `),insertSetting:this.db.prepare(`
          INSERT INTO settings (key, value, description, category, is_active) 
          VALUES (?, ?, ?, ?, ?)
        `),updateSetting:this.db.prepare(`
          UPDATE settings SET
            value = ?, description = ?, category = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
          WHERE key = ?
        `),upsertSetting:this.db.prepare(`
          INSERT INTO settings (key, value, description, category, is_active) 
          VALUES (?, ?, ?, ?, ?)
          ON CONFLICT(key) DO UPDATE SET
            value = excluded.value,
            description = excluded.description,
            category = excluded.category,
            is_active = excluded.is_active,
            updated_at = CURRENT_TIMESTAMP
        `),deleteSetting:this.db.prepare("DELETE FROM settings WHERE key = ?"),getOTP:this.db.prepare(`
          SELECT * FROM otps WHERE email = ?
        `),storeOTP:this.db.prepare(`
          INSERT OR REPLACE INTO otps (email, code, expires_at, attempts) 
          VALUES (?, ?, ?, ?)
        `),updateOTPAttempts:this.db.prepare(`
          UPDATE otps SET attempts = ? WHERE email = ?
        `),deleteOTP:this.db.prepare("DELETE FROM otps WHERE email = ?"),deleteExpiredOTPs:this.db.prepare(`
          DELETE FROM otps WHERE expires_at < ?
        `)},await this.insertDefaultCities(),await this.insertDefaultSettings(),this.needsSlugsGeneration&&(await this.generateMissingSlugs(),this.needsSlugsGeneration=!1),this.isInitialized=!0,console.log(`Events database initialized: ${this.options.dbPath}`)}catch(e){throw console.error("Failed to initialize events database:",e),e}}async insertDefaultCities(){for(let e of[{slug:"riyadh",name_ar:"الرياض",name_en:"Riyadh",country:"SA"},{slug:"jeddah",name_ar:"جدة",name_en:"Jeddah",country:"SA"},{slug:"dammam",name_ar:"الدمام",name_en:"Dammam",country:"SA"},{slug:"mecca",name_ar:"مكة المكرمة",name_en:"Mecca",country:"SA"},{slug:"medina",name_ar:"المدينة المنورة",name_en:"Medina",country:"SA"},{slug:"khobar",name_ar:"الخبر",name_en:"Khobar",country:"SA"},{slug:"taif",name_ar:"الطائف",name_en:"Taif",country:"SA"},{slug:"tabuk",name_ar:"تبوك",name_en:"Tabuk",country:"SA"},{slug:"buraidah",name_ar:"بريدة",name_en:"Buraidah",country:"SA"},{slug:"khamis-mushait",name_ar:"خميس مشيط",name_en:"Khamis Mushait",country:"SA"},{slug:"hail",name_ar:"حائل",name_en:"Hail",country:"SA"},{slug:"hofuf",name_ar:"الهفوف",name_en:"Hofuf",country:"SA"},{slug:"mubarraz",name_ar:"المبرز",name_en:"Mubarraz",country:"SA"},{slug:"qatif",name_ar:"القطيف",name_en:"Qatif",country:"SA"},{slug:"jubail",name_ar:"الجبيل",name_en:"Jubail",country:"SA"},{slug:"najran",name_ar:"نجران",name_en:"Najran",country:"SA"},{slug:"jazan",name_ar:"جازان",name_en:"Jazan",country:"SA"},{slug:"yanbu",name_ar:"ينبع",name_en:"Yanbu",country:"SA"},{slug:"abha",name_ar:"أبها",name_en:"Abha",country:"SA"},{slug:"arar",name_ar:"عرعر",name_en:"Arar",country:"SA"},{slug:"sakaka",name_ar:"سكاكا",name_en:"Sakaka",country:"SA"},{slug:"al-bahah",name_ar:"الباحة",name_en:"Al Bahah",country:"SA"},{slug:"qurayyat",name_ar:"القريات",name_en:"Qurayyat",country:"SA"},{slug:"bisha",name_ar:"بيشة",name_en:"Bisha",country:"SA"},{slug:"dhahran",name_ar:"الظهران",name_en:"Dhahran",country:"SA"}])try{this.statements.getCityBySlug.get(e.slug)||this.statements.insertCity.run(e.slug,e.name_ar,e.name_en,e.country,1)}catch(e){}}async insertDefaultSettings(){for(let e of[{key:"telegram_bot_token",value:"7898415400:AAF4I6oiuRmLl40r5U-NROl3oENddUlVv5U",description:"Telegram Bot Token for notifications",category:"telegram"},{key:"telegram_chat_id",value:"6032588551",description:"Telegram Chat ID for notifications",category:"telegram"},{key:"whatsapp_number",value:"971501408768",description:"WhatsApp support number displayed in footer",category:"contact"},{key:"support_phone",value:"920008640",description:"Support phone number displayed in footer",category:"contact"}])try{this.statements.getSettingByKey.get(e.key)||(this.statements.insertSetting.run(e.key,e.value,e.description,e.category,1),console.log(`Inserted default setting: ${e.key}`))}catch(t){console.error(`Error inserting default setting ${e.key}:`,t)}}async ensureInitialized(){this.isInitialized||await this.init()}generateSlug(e,t=100){let s={ا:"a",أ:"a",إ:"i",آ:"aa",ب:"b",ت:"t",ث:"th",ج:"j",ح:"h",خ:"kh",د:"d",ذ:"th",ر:"r",ز:"z",س:"s",ش:"sh",ص:"s",ض:"d",ط:"t",ظ:"z",ع:"a",غ:"gh",ف:"f",ق:"q",ك:"k",ل:"l",م:"m",ن:"n",ه:"h",و:"w",ي:"y",ى:"a",ة:"h",ء:"a","٠":"0","١":"1","٢":"2","٣":"3","٤":"4","٥":"5","٦":"6","٧":"7","٨":"8","٩":"9","۰":"0","۱":"1","۲":"2","۳":"3","۴":"4","۵":"5","۶":"6","۷":"7","۸":"8","۹":"9"},i=e.toLowerCase().trim().replace(/[\u064B-\u0652\u0670\u0640]/g,"").replace(/[\u0600-\u06FF]/g,e=>s[e]||"").replace(/[\s\u060C\u061F\u061B\u06D4\u002C\u003F\u0021\u003B\u003A\u002E\u0027\u0022\u0028\u0029\u005B\u005D\u007B\u007D\u002F\u005C\u007C\u002B\u003D\u0026\u0025\u0024\u0023\u0040\u005E\u002A\u007E\u0060]+/g,"-").replace(/-+/g,"-").replace(/^-+|-+$/g,"").replace(/[^a-z0-9-]/g,"").substring(0,t).replace(/-+$/,"");return(!i||i.length<3)&&(i=`event-${Date.now()}`),i}async getUniqueSlug(e,t=null){let s=this.generateSlug(e),i=s,a=1;for(;;){let e=this.statements.checkSlugExists.get(i);if(!e||t&&e.id===t)break;if(i=`${s}-${a}`,++a>1e3){i=`${s}-${Date.now()}`;break}}return i}async generateMissingSlugs(){try{let e=this.db.prepare(`
        SELECT id, title FROM ${this.options.tableName} 
        WHERE slug IS NULL OR slug = ''
      `).all();if(0===e.length)return void console.log("All events already have slugs");console.log(`Generating slugs for ${e.length} events...`);let t=this.db.prepare(`
        UPDATE ${this.options.tableName} SET slug = ? WHERE id = ?
      `);for(let s of e)try{let e=await this.getUniqueSlug(s.title,s.id);t.run(e,s.id),console.log(`Generated slug "${e}" for event ID ${s.id}`)}catch(e){console.error("Error generating slug for event:",s.id,e)}console.log("Finished generating slugs for existing events")}catch(e){console.error("Error in generateMissingSlugs:",e)}}async getAllEvents(){return await this.ensureInitialized(),this.statements.getAllEvents.all()}async getEventsByCity(e){return await this.ensureInitialized(),this.statements.getEventsByCity.all(e)}async getEventById(e){return await this.ensureInitialized(),this.statements.getEventById.get(e)}async getEventBySlug(e){return await this.ensureInitialized(),this.statements.getEventBySlug.get(e)}async createEvent(e){await this.ensureInitialized();try{let t=await this.getUniqueSlug(e.title),s=this.statements.insertEvent.run(e.city_slug,t,e.title,e.description||null,e.price||null,e.crossed_price||null,e.global_price||null,e.gold_price||null,e.platinum_price||null,e.vip_price||null,e.silver_price||null,e.diamond_price||null,e.pricing_currency||"SAR",e.date||null,e.start_time||null,e.end_time||null,e.venue||null,e.address||null,e.google_maps_link||null,e.category||null,e.label||null,e.rating||null,e.accelerator||null,e.accelerator_type||null,e.discount||null,e.href||null,e.external_url||null,e.image_url||null,e.image_full||null,e.mobile_thumb||null,e.alt||null,e.is_featured||0,void 0!==e.is_active?e.is_active:1,e.priority||0,e.tags?JSON.stringify(e.tags):null,e.metadata?JSON.stringify(e.metadata):null);return{success:!0,id:s.lastInsertRowid,slug:t}}catch(e){return console.error("Error creating event:",e),{success:!1,error:e.message}}}async updateEvent(e,t){await this.ensureInitialized();try{let s=this.statements.updateEvent.run(t.title,t.description||null,t.price||null,t.crossed_price||null,t.global_price||null,t.gold_price||null,t.platinum_price||null,t.vip_price||null,t.silver_price||null,t.diamond_price||null,t.pricing_currency||"SAR",t.date||null,t.start_time||null,t.end_time||null,t.venue||null,t.address||null,t.google_maps_link||null,t.category||null,t.label||null,t.rating||null,t.accelerator||null,t.accelerator_type||null,t.discount||null,t.href||null,t.external_url||null,t.image_url||null,t.image_full||null,t.mobile_thumb||null,t.alt||null,t.is_featured||0,void 0!==t.is_active?t.is_active:1,t.priority||0,t.tags?JSON.stringify(t.tags):null,t.metadata?JSON.stringify(t.metadata):null,e);return{success:!0,changes:s.changes}}catch(e){return console.error("Error updating event:",e),{success:!1,error:e.message}}}async deleteEvent(e){await this.ensureInitialized();try{let t=this.statements.deleteEvent.run(e);return{success:!0,changes:t.changes}}catch(e){return console.error("Error deleting event:",e),{success:!1,error:e.message}}}async toggleEventStatus(e,t){await this.ensureInitialized();try{let s=this.statements.toggleEventStatus.run(+!!t,e);return{success:!0,changes:s.changes}}catch(e){return console.error("Error toggling event status:",e),{success:!1,error:e.message}}}async getAllCities(){return await this.ensureInitialized(),this.statements.getAllCities.all()}async getCityBySlug(e){return await this.ensureInitialized(),this.statements.getCityBySlug.get(e)}async createCity(e){await this.ensureInitialized();try{let t=this.statements.insertCity.run(e.slug,e.name_ar,e.name_en,e.country||"SA",void 0!==e.is_active?e.is_active:1);return{success:!0,id:t.lastInsertRowid}}catch(e){return console.error("Error creating city:",e),{success:!1,error:e.message}}}async updateCity(e,t){await this.ensureInitialized();try{let s=this.statements.updateCity.run(t.name_ar,t.name_en,t.country||"SA",void 0!==t.is_active?t.is_active:1,e);return{success:!0,changes:s.changes}}catch(e){return console.error("Error updating city:",e),{success:!1,error:e.message}}}async getEventStats(){return await this.ensureInitialized(),this.statements.getEventStats.get()}async getCityEventCounts(){return await this.ensureInitialized(),this.statements.getCityEventCounts.all()}async getAllSettings(){return await this.ensureInitialized(),this.statements.getAllSettings.all()}async getSettingByKey(e){return await this.ensureInitialized(),this.statements.getSettingByKey.get(e)}async getSettingsByCategory(e){return await this.ensureInitialized(),this.statements.getSettingsByCategory.all(e)}async createSetting(e){await this.ensureInitialized();try{let t=this.statements.insertSetting.run(e.key,e.value,e.description||null,e.category||"general",void 0!==e.is_active?e.is_active:1);return{success:!0,id:t.lastInsertRowid}}catch(e){return console.error("Error creating setting:",e),{success:!1,error:e.message}}}async updateSetting(e,t){await this.ensureInitialized();try{let s=this.statements.updateSetting.run(t.value,t.description||null,t.category||"general",void 0!==t.is_active?t.is_active:1,e);return{success:!0,changes:s.changes}}catch(e){return console.error("Error updating setting:",e),{success:!1,error:e.message}}}async upsertSetting(e){await this.ensureInitialized();try{let t=this.statements.upsertSetting.run(e.key,e.value,e.description||null,e.category||"general",void 0!==e.is_active?e.is_active:1);return{success:!0,changes:t.changes}}catch(e){return console.error("Error upserting setting:",e),{success:!1,error:e.message}}}async deleteSetting(e){await this.ensureInitialized();try{let t=this.statements.deleteSetting.run(e);return{success:!0,changes:t.changes}}catch(e){return console.error("Error deleting setting:",e),{success:!1,error:e.message}}}async getOTP(e){return await this.ensureInitialized(),this.statements.getOTP.get(e)}async storeOTP(e,t,s,i=0){await this.ensureInitialized();try{let a=this.statements.storeOTP.run(e,t,s,i);return{success:!0,changes:a.changes}}catch(e){return console.error("Error storing OTP:",e),{success:!1,error:e.message}}}async updateOTPAttempts(e,t){await this.ensureInitialized();try{let s=this.statements.updateOTPAttempts.run(t,e);return{success:!0,changes:s.changes}}catch(e){return console.error("Error updating OTP attempts:",e),{success:!1,error:e.message}}}async deleteOTP(e){await this.ensureInitialized();try{let t=this.statements.deleteOTP.run(e);return{success:!0,changes:t.changes}}catch(e){return console.error("Error deleting OTP:",e),{success:!1,error:e.message}}}async deleteExpiredOTPs(){await this.ensureInitialized();try{let e=this.statements.deleteExpiredOTPs.run(Date.now());return{success:!0,changes:e.changes}}catch(e){return console.error("Error deleting expired OTPs:",e),{success:!1,error:e.message}}}async close(){if(this.db)try{this.db.close(),this.db=null,this.isInitialized=!1,console.log("Events database connection closed")}catch(e){console.error("Error closing events database:",e)}}}let u=null;function E(e={}){return u||(u=new o(e)),u}},78335:()=>{},96487:()=>{}};