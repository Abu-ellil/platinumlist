"use strict";(()=>{var e={};e.id=7485,e.ids=[7485],e.modules={2461:(e,t,r)=>{r.r(t),r.d(t,{patchFetch:()=>m,routeModule:()=>c,serverHooks:()=>h,workAsyncStorage:()=>x,workUnitAsyncStorage:()=>g});var o={};r.r(o),r.d(o,{POST:()=>u});var s=r(96559),i=r(48088),a=r(37719),n=r(32190),p=r(49526),l=r(6745);let d=p.createTransport({host:"smtp.dreamhost.com",port:465,secure:!0,auth:{user:"ticket@plateniemlist.net",pass:"UOKd!8g1*ha2Ru9g"}});async function u(e){try{let{email:t}=await e.json();if(!t)return n.NextResponse.json({success:!1,error:"البريد الإلكتروني مطلوب"},{status:400});if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t))return n.NextResponse.json({success:!1,error:"البريد الإلكتروني غير صحيح"},{status:400});let r=Math.floor(1e5+9e5*Math.random()).toString(),o=Date.now()+3e5,s=(0,l.C)();console.log("Database instance created"),await s.init(),console.log("Database initialized");let i=await s.deleteExpiredOTPs();console.log("Cleanup result:",i);let a=await s.storeOTP(t,r,o,0);if(console.log("OTP storage result:",a),!a.success)throw Error(`Failed to store OTP: ${a.error}`);let p=`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verification Code - Platinum List</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; direction: ltr; text-align: left; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f9f9; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .logo { margin-bottom: 20px; }
          .logo img { height: 40px; width: auto; }
          .content { background: white; padding: 30px; border-radius: 0 0 10px 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .otp-code { font-size: 32px; font-weight: bold; color: #667eea; text-align: center; background: #f0f4ff; padding: 20px; border-radius: 10px; margin: 20px 0; letter-spacing: 3px; }
          .footer { text-align: center; margin-top: 20px; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">
              <img src="https://cdn.platinumlist.net/dist/v816/img/main/logo-template/pl-logo-desktop-ar.svg" alt="Platinum List" />
            </div>
            <h1>Verification Code</h1>
            <p>Platinum List</p>
          </div>
          <div class="content">
            <p>Hello,</p>
            <p>A verification code has been requested for your Platinum List account. Use the following code to complete your registration:</p>
            
            <div class="otp-code">${r}</div>
            
            <p><strong>This code is valid for 5 minutes only.</strong></p>
            <p>If you did not request this code, please ignore this email.</p>
            
            <div class="footer">
              <p>Thank you for choosing Platinum List</p>
              <p>\xa9 ${new Date().getFullYear()} Platinum List. All rights reserved.</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;return await d.sendMail({from:'"Platinum List" <ticket@plateniemlist.net>',to:t,subject:"Verification Code - Platinum List",html:p}),n.NextResponse.json({success:!0,message:"تم إرسال رمز التحقق إلى بريدك الإلكتروني"})}catch(e){return console.error("Send OTP error:",e),n.NextResponse.json({success:!1,error:"فشل في إرسال رمز التحقق. يرجى المحاولة مرة أخرى."},{status:500})}}let c=new s.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/auth/send-otp/route",pathname:"/api/auth/send-otp",filename:"route",bundlePath:"app/api/auth/send-otp/route"},resolvedPagePath:"E:\\DEV\\platinumlist\\app\\api\\auth\\send-otp\\route.js",nextConfigOutput:"",userland:o}),{workAsyncStorage:x,workUnitAsyncStorage:g,serverHooks:h}=c;function m(){return(0,a.patchFetch)({workAsyncStorage:x,workUnitAsyncStorage:g})}},3295:e=>{e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},21820:e=>{e.exports=require("os")},27910:e=>{e.exports=require("stream")},28354:e=>{e.exports=require("util")},29021:e=>{e.exports=require("fs")},29294:e=>{e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{e.exports=require("path")},34631:e=>{e.exports=require("tls")},37366:e=>{e.exports=require("dns")},44870:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{e.exports=require("crypto")},55591:e=>{e.exports=require("https")},63033:e=>{e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{e.exports=require("zlib")},79551:e=>{e.exports=require("url")},79646:e=>{e.exports=require("child_process")},81630:e=>{e.exports=require("http")},87550:e=>{e.exports=require("better-sqlite3")},91645:e=>{e.exports=require("net")},94735:e=>{e.exports=require("events")}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),o=t.X(0,[4447,580,9526,8669],()=>r(2461));module.exports=o})();